#!/usr/bin/env python3
import json,queue,subprocess,threading,tkinter as tk
from tkinter import ttk
from pathlib import Path

HOME=Path.home();BASE=HOME/".local/share/collarpet-link";KEY=HOME/".ssh/id_ed25519_collarpet";CFG=HOME/".config/collarpet/link.conf"
C={}
if CFG.exists():
    for line in CFG.read_text().splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            k,v=line.split("=",1);C[k.strip()]=v.strip().strip('"')
PORT=int(C.get("HELLO_PORT",47842));USER=C.get("COLLARPET_USER","jenna");SSHPORT=C.get("COLLARPET_SSH_PORT","22")
jobs=queue.Queue()

root=tk.Tk();root.title("PetMind Training Recorder");root.geometry("700x430")
status=tk.StringVar(value="AUTO uses LAN/Recovery AP first, BLE fallback.")
transport=tk.StringVar(value="AUTO");duration=tk.IntVar(value=30)

def discover():
    p=subprocess.run(["python3",str(BASE/"discover.py"),str(PORT),"2"],capture_output=True,text=True,timeout=8)
    if p.returncode:return None
    try:
        d=json.loads(p.stdout);return d.get("_source_ip") or d.get("ip")
    except Exception:return None

def send_wifi(args):
    ip=discover()
    if not ip or not KEY.exists():raise RuntimeError("LAN unavailable")
    p=subprocess.run(["ssh","-i",str(KEY),"-p",SSHPORT,"-o","BatchMode=yes","-o","ConnectTimeout=3",
                      f"{USER}@{ip}","/usr/local/bin/cp-petmind-record",*args],capture_output=True,text=True,timeout=10)
    if p.returncode:raise RuntimeError((p.stderr or p.stdout)[-250:])
    return "Wi-Fi",json.loads(p.stdout)

def send_ble(args):
    p=subprocess.run(["sudo","-n","/usr/local/sbin/cp-training-ble-send",*args],capture_output=True,text=True,timeout=12)
    if p.returncode:raise RuntimeError((p.stderr or p.stdout)[-250:])
    return "BLE",{"ok":True,"message":p.stdout.strip()}

def send(args):
    mode=transport.get()
    if mode in ("AUTO","Wi-Fi"):
        try:return send_wifi(args)
        except Exception:
            if mode=="Wi-Fi":raise
    return send_ble(args)

def background(args):
    status.set("Sending…")
    def work():
        try:jobs.put(("ok",send(args)))
        except Exception as e:jobs.put(("err",str(e)))
    threading.Thread(target=work,daemon=True).start()

def rescue(action):
    h=HOME/".local/bin/cp-rescue"
    if not h.exists():status.set("cp-rescue is not installed.");return
    def work():
        try:
            p=subprocess.run([str(h),action],capture_output=True,text=True,timeout=100)
            jobs.put(("ok",("RESCUE",json.loads(p.stdout))))
        except Exception as e:jobs.put(("err",str(e)))
    threading.Thread(target=work,daemon=True).start()

def poll():
    try:
        while True:
            kind,val=jobs.get_nowait()
            if kind=="ok":
                via,obj=val;status.set(f"{via}: "+(obj.get("message") or json.dumps(obj.get("status",obj))))
            else:status.set("ERROR: "+val)
    except queue.Empty:pass
    root.after(100,poll)

top=tk.Frame(root);top.pack(fill="x",padx=10,pady=8)
tk.Label(top,text="PETMIND TRAINING",font=("DejaVu Sans",18,"bold")).pack(side="left")
ttk.Combobox(top,textvariable=transport,values=["AUTO","Wi-Fi","BLE"],state="readonly",width=8).pack(side="right")

ctrl=tk.LabelFrame(root,text="Recorder");ctrl.pack(fill="x",padx=10,pady=5)
for t,a in [("START",["start"]),("STOP",["stop"]),("STATUS",["status"]),("CLEAR LABEL",["clear"])]:
    tk.Button(ctrl,text=t,command=lambda x=a:background(x)).pack(side="left",expand=True,fill="x",padx=3,pady=5)

dur=tk.Frame(root);dur.pack(fill="x",padx=10)
tk.Label(dur,text="Label duration (s):").pack(side="left")
tk.Spinbox(dur,from_=5,to=255,textvariable=duration,width=6).pack(side="left",padx=5)

labels=tk.LabelFrame(root,text="Context label");labels.pack(fill="both",expand=True,padx=10,pady=5)
for i,n in enumerate(["quiet","resting","speech","music","walking","crowd","machinery","dark_active","ef_badges","fox","riding","outdoor","other"]):
    tk.Button(labels,text=n.replace("_"," ").upper(),command=lambda x=n:background(["label",x,str(duration.get())])).grid(row=i//5,column=i%5,sticky="ew",padx=2,pady=2)
for c in range(5):labels.columnconfigure(c,weight=1)

events=tk.LabelFrame(root,text="Instant event marker");events.pack(fill="x",padx=10,pady=5)
for n in ["bang","clap","surprise","unexpected_noise","fox_appeared"]:
    tk.Button(events,text=n.replace("_"," ").upper(),command=lambda x=n:background(["event",x])).pack(side="left",expand=True,fill="x",padx=2,pady=4)

res=tk.Frame(root);res.pack(fill="x",padx=10,pady=4)
tk.Button(res,text="START RESCUE AP",command=lambda:rescue("start")).pack(side="left",expand=True,fill="x",padx=2)
tk.Button(res,text="STOP RESCUE AP",command=lambda:rescue("stop")).pack(side="left",expand=True,fill="x",padx=2)
tk.Label(root,textvariable=status,anchor="w",wraplength=670).pack(fill="x",padx=10,pady=8)
poll();root.mainloop()
