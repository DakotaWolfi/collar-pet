#!/usr/bin/env python3
import asyncio, json, os, pwd, time
from collections import deque
from datetime import datetime
from pathlib import Path

SOCKET=Path("/run/collarpet-training/control.sock")
DATA_DIR=Path("/home/jenna/collarpet/petmind-data")
MAGIC=b"CPTR"
CONTEXT={1:"quiet",2:"resting",3:"speech",4:"music",5:"walking",6:"crowd",7:"machinery",8:"dark_active",9:"ef_badges",10:"fox",11:"riding",12:"outdoor",13:"other"}
EVENTS={1:"bang",2:"clap",3:"surprise",4:"unexpected_noise",5:"fox_appeared"}

class Recorder:
    def __init__(self):
        self.active=False; self.path=None; self.stream=None; self.frame=0
        self.label=None; self.label_until=0.0; self.pending=deque(); self.recent={}
        self.last_frame=0.0; self.started=None; self.last_error=""; self.ns=None

    def _chown_jenna(self,p):
        try:
            u=pwd.getpwnam("jenna"); os.chown(p,u.pw_uid,u.pw_gid)
        except Exception: pass

    def _write(self,obj):
        if self.stream:
            self.stream.write(json.dumps(obj,separators=(",",":"),ensure_ascii=True)+"\n")
            self.stream.flush()

    def _event(self,name,**kw):
        self._write({"record_type":"event","time":datetime.now().isoformat(timespec="milliseconds"),
                     "monotonic":round(time.monotonic(),6),"event":name,**kw})

    def status(self):
        remain=max(0,int(self.label_until-time.monotonic())) if self.label else 0
        return {"active":self.active,"file":str(self.path) if self.path else None,"frames":self.frame,
                "label":self.label,"label_seconds_remaining":remain,"started":self.started,
                "last_error":self.last_error or None}

    def start(self,source="local"):
        if self.active:return {"ok":True,"message":"already recording","status":self.status()}
        DATA_DIR.mkdir(parents=True,exist_ok=True);self._chown_jenna(DATA_DIR)
        self.path=DATA_DIR/(datetime.now().strftime("%Y%m%d-%H%M%S")+"-petmind-real.jsonl")
        self.stream=self.path.open("a",encoding="utf-8",buffering=1);self._chown_jenna(self.path)
        self.active=True;self.frame=0;self.started=datetime.now().isoformat(timespec="seconds")
        self._write({"record_type":"session","schema_version":1,"started":self.started,"feature_count":28,
                     "history_frames":16,"note":"context_label is a human annotation, not automatically a target expression"})
        self._event("start",source=source)
        return {"ok":True,"message":"recording started","status":self.status()}

    def stop(self,source="local"):
        if not self.active:return {"ok":True,"message":"already stopped","status":self.status()}
        self._event("stop",source=source);old=str(self.path)
        self.active=False;self.label=None;self.label_until=0
        self.stream.close();self.stream=None;self.path=None
        return {"ok":True,"message":"recording stopped","file":old,"status":self.status()}

    def label_for(self,label,seconds=30,source="local"):
        if label not in CONTEXT.values():return {"ok":False,"error":"unknown label"}
        if not self.active:self.start(source)
        seconds=max(1,min(900,int(seconds)));self.label=label;self.label_until=time.monotonic()+seconds
        self._event("label",label=label,seconds=seconds,source=source)
        return {"ok":True,"message":f"{label} for {seconds}s","status":self.status()}

    def clear(self,source="local"):
        old=self.label;self.label=None;self.label_until=0
        if self.active:self._event("label_clear",previous=old,source=source)
        return {"ok":True,"message":"label cleared","status":self.status()}

    def mark(self,label,source="local"):
        if label not in EVENTS.values():return {"ok":False,"error":"unknown event"}
        if not self.active:self.start(source)
        self._event("marker",label=label,source=source,pre_seconds=10,post_seconds=5)
        return {"ok":True,"message":"marked "+label,"status":self.status()}

    def execute(self,req,source="socket"):
        op=str(req.get("op","")).lower()
        if op=="status":return {"ok":True,"status":self.status(),"contexts":list(CONTEXT.values()),"events":list(EVENTS.values())}
        if op=="start":return self.start(source)
        if op=="stop":return self.stop(source)
        if op=="clear":return self.clear(source)
        if op=="label":return self.label_for(str(req.get("label","")).lower(),req.get("seconds",30),source)
        if op=="event":return self.mark(str(req.get("label","")).lower(),source)
        return {"ok":False,"error":"unknown op"}

    def handle_remote(self,parts):
        try:
            op=parts[1].upper()
            if op in ("START","STOP","CLEAR"):
                self.pending.append(({"op":op.lower()},"remote"));return True
            if op=="LABEL" and len(parts)>=3:
                self.pending.append(({"op":"label","label":parts[2].lower(),"seconds":int(parts[3]) if len(parts)>3 else 30},"remote"));return True
            if op=="EVENT" and len(parts)>=3:
                self.pending.append(({"op":"event","label":parts[2].lower()},"remote"));return True
        except Exception as e:self.last_error=str(e)
        return False

    def handle_ble(self,payload,address="?"):
        try:
            p=bytes(payload or b"")
            if len(p)<9 or p[:4]!=MAGIC or p[4]!=1:return False
            seq,cmd,arg,dur=p[5],p[6],p[7],p[8];now=time.monotonic();key=(str(address),seq)
            self.recent={k:t for k,t in self.recent.items() if now-t<30}
            if key in self.recent:return True
            self.recent[key]=now;req=None
            if cmd==1:req={"op":"start"}
            elif cmd==2:req={"op":"stop"}
            elif cmd==3:req={"op":"clear"}
            elif cmd==4 and arg in CONTEXT:req={"op":"label","label":CONTEXT[arg],"seconds":max(1,dur)}
            elif cmd==5 and arg in EVENTS:req={"op":"event","label":EVENTS[arg]}
            if req:self.pending.append((req,"ble:"+str(address)))
            return True
        except Exception as e:self.last_error=str(e);return False

    def snapshot(self):
        ns=self.ns;now=time.monotonic();items=ns["visible_devices"](now);g=ns["esp"].gps
        fresh=bool(g.last_update) and now-g.last_update<ns["GPS_STALE_SECONDS"]
        speed=g.speed_kmh if fresh and g.fix else 0.0
        feat=ns["neural_state_dict"](now,items,speed);n=ns["neural"]
        return {"record_type":"frame","frame_seq":self.frame,"time":datetime.now().isoformat(timespec="milliseconds"),
                "monotonic":round(now,6),"context_label":self.label if self.label and now<self.label_until else None,
                "features":feat,"prediction":n.expression if n.available else None,
                "confidence":round(float(n.confidence),6) if n.available else None,
                "top":[{"expression":k,"probability":round(float(v),6)} for k,v in list(n.top)[:4]],
                "world_mood":ns["world"].mood,"world_activity":ns["world"].activity,"world_reason":ns["world"].reason}

    async def client(self,reader,writer):
        try:
            raw=await asyncio.wait_for(reader.readline(),5);res=self.execute(json.loads(raw),"socket")
        except Exception as e:res={"ok":False,"error":str(e)}
        try:writer.write(json.dumps(res).encode()+b"\n");await writer.drain()
        except Exception:pass
        writer.close()

    async def run(self,namespace):
        self.ns=namespace;SOCKET.parent.mkdir(parents=True,exist_ok=True);self._chown_jenna(SOCKET.parent);SOCKET.unlink(missing_ok=True)
        server=await asyncio.start_unix_server(self.client,path=str(SOCKET));self._chown_jenna(SOCKET);os.chmod(SOCKET,0o660)
        try:
            while not namespace["stop_event"].is_set():
                while self.pending:
                    req,src=self.pending.popleft();r=self.execute(req,src);print("[PETMIND TRAIN] "+r.get("message",r.get("error","")))
                now=time.monotonic()
                if self.label and now>=self.label_until:self.clear("timer")
                if self.active and now-self.last_frame>=0.5:
                    self.last_frame=now
                    try:self._write(self.snapshot());self.frame+=1
                    except Exception as e:self.last_error=str(e);print("[PETMIND TRAIN] frame error:",e)
                await asyncio.sleep(0.05)
        finally:
            server.close();await server.wait_closed();SOCKET.unlink(missing_ok=True)
            if self.stream:self.stream.close()
