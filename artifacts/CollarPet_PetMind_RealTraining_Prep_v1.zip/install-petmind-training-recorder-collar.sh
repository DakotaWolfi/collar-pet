#!/usr/bin/env bash
set -Eeuo pipefail
[[ "${1:-}" == "collarpet" ]] || { echo "Usage: sudo bash install-petmind-training-recorder-collar.sh collarpet [--rollback]"; exit 2; }
[[ "${EUID:-$(id -u)}" -eq 0 ]] || { echo "Run with sudo."; exit 2; }

HERE="$(cd "$(dirname "$0")" && pwd)"
LIVE=/home/jenna/collarpet/collarpet.py
PY=/home/jenna/mindtest/bin/python
UNIT=collarpet.service
ROOT=/usr/local/lib/collarpet-training
BACK=/var/backups/collarpet-training-recorder
mkdir -p "$BACK"

latest(){ find "$BACK" -maxdepth 1 -type f -name 'collarpet.py.*.bak' -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -1 | cut -d' ' -f2-; }

if [[ "${2:-}" == "--rollback" ]]; then
  B="$(latest || true)"; [[ -n "$B" ]] || { echo "No backup found."; exit 1; }
  systemctl stop "$UNIT" || true
  cp -a "$B" "$LIVE"
  "$PY" -m py_compile "$LIVE"
  systemctl start "$UNIT"
  echo "Rolled back to $B"
  exit 0
fi

for f in petmind_recorder.py cp-petmind-record.py; do [[ -f "$HERE/$f" ]] || { echo "Missing $HERE/$f"; exit 1; }; done
[[ -s "$LIVE" ]] || { echo "Missing/empty $LIVE"; exit 1; }

STAMP=$(date +%Y%m%d-%H%M%S)
BAK="$BACK/collarpet.py.$STAMP.bak"
cp -a "$LIVE" "$BAK"
echo "Backup: $BAK"

TMP=$(mktemp)
cp "$LIVE" "$TMP"
trap 'rm -f "$TMP"' EXIT

python3 - "$TMP" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
MARK="# COLLARPET_PETMIND_TRAINING_RECORDER_V1"
if MARK in s:
    print("Runtime recorder patch already present.")
    raise SystemExit(0)

helper='''# COLLARPET_PETMIND_TRAINING_RECORDER_V1
petmind_training_recorder = None

async def petmind_training_task():
    global petmind_training_recorder
    import runpy
    module = runpy.run_path("/usr/local/lib/collarpet-training/petmind_recorder.py")
    petmind_training_recorder = module["Recorder"]()
    try:
        await petmind_training_recorder.run(globals())
    except asyncio.CancelledError:
        raise
    except Exception:
        LOGGER.exception("PetMind training recorder stopped unexpectedly")


'''
anchor="async def main():"
if s.count(anchor)!=1:raise SystemExit("Could not find unique async def main()")
s=s.replace(anchor,helper+anchor,1)

task='        asyncio.create_task(remote_mirror_task(), name="remote-mirror"),'
if task not in s:raise SystemExit("Could not find remote-mirror task")
s=s.replace(task,task+'\n        asyncio.create_task(petmind_training_task(), name="petmind-training"),',1)

ble='        service_uuids = [u.lower() for u in (getattr(advertisement_data, "service_uuids", None) or [])]\n'
if s.count(ble)!=1:raise SystemExit("Could not find BLE callback anchor")
ble_new=ble+'''        if petmind_training_recorder is not None:
            marker = (getattr(advertisement_data, "manufacturer_data", None) or {}).get(0xFFFF)
            if marker is not None and petmind_training_recorder.handle_ble(marker, address):
                return

'''
s=s.replace(ble,ble_new,1)

power='    if len(parts) >= 2 and parts[0] == "POWER":\n'
if s.count(power)!=1:raise SystemExit("Could not find POWER command anchor")
s=s.replace(power,'''    if parts and parts[0] == "TRAIN" and petmind_training_recorder is not None:
        if petmind_training_recorder.handle_remote(parts):
            return

'''+power,1)

compile(s,str(p),"exec")
p.write_text(s)
print("Runtime patch prepared.")
PY

"$PY" -m py_compile "$TMP" "$HERE/petmind_recorder.py"
python3 -m py_compile "$HERE/cp-petmind-record.py"

WAS=0
systemctl is-active --quiet "$UNIT" && WAS=1 || true
systemctl stop "$UNIT" || true

install -d -o root -g root -m 0755 "$ROOT"
install -o root -g root -m 0644 "$HERE/petmind_recorder.py" "$ROOT/petmind_recorder.py"
install -o root -g root -m 0755 "$HERE/cp-petmind-record.py" /usr/local/bin/cp-petmind-record
install -d -o jenna -g jenna -m 0775 /home/jenna/collarpet/petmind-data
install -o "$(stat -c %u "$LIVE")" -g "$(stat -c %g "$LIVE")" -m "$(stat -c %a "$LIVE")" "$TMP" "$LIVE"
"$PY" -m py_compile "$LIVE"

if [[ "$WAS" == 1 ]]; then
  systemctl start "$UNIT"; sleep 4
  if ! systemctl is-active --quiet "$UNIT"; then
    echo "CollarPet failed after install; restoring backup."
    systemctl stop "$UNIT" || true
    cp -a "$BAK" "$LIVE"
    "$PY" -m py_compile "$LIVE"
    systemctl start "$UNIT" || true
    exit 1
  fi
fi

echo "Recorder installed."
echo "Test with: cp-petmind-record status"
echo "Data directory: /home/jenna/collarpet/petmind-data/"
