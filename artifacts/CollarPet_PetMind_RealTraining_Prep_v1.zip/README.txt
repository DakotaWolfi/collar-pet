PetMind real-world training prep v1

COLLAR
------
Copy/extract this folder on CollarPet, then:
  sudo bash install-petmind-training-recorder-collar.sh collarpet
  cp-petmind-record status

Recorder output:
  /home/jenna/collarpet/petmind-data/*-petmind-real.jsonl

It stores a frame about every 0.5 s while recording:
- all 28 PetMind features
- shadow prediction, confidence, top-4
- current human context label
- current world mood/activity/reason

Instant events (bang/clap/etc.) are timestamped so we can reconstruct the
10 s before and 5 s after the event later.

PT35
----
Copy/extract this folder on PT35, then:
  bash install-petmind-training-ui-pt35.sh pt35

Close/reopen cp-dashboard. A TRAIN button appears.

Transport AUTO:
1) tries normal LAN or the Recovery AP using the existing SSH key
2) if unavailable, sends a short BLE advertising marker

BLE fallback:
- no extra GATT connection
- PT35 advertises manufacturer ID 0xFFFF with magic CPTR
- CollarPet's existing environmental scanner receives it
- duplicate advertisements are ignored by sequence number

Recovery AP:
The Training window includes START RESCUE AP / STOP RESCUE AP and uses:
  ~/.local/bin/cp-rescue
The PT35 installer explicitly reports whether that helper exists.

Suggested field workflow:
1) START recorder.
2) Set a 30-120 s context label while doing something real.
3) Use EVENT for short impulses such as a bang or surprise.
4) Let some ordinary time run unlabeled too.
5) STOP after the session.
