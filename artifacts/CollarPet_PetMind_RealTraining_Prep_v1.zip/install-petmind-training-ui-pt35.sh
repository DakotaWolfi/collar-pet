#!/usr/bin/env bash
set -Eeuo pipefail
[[ "${1:-}" == "pt35" ]] || { echo "Usage: bash install-petmind-training-ui-pt35.sh pt35 [--rollback]"; exit 2; }
[[ "${EUID:-$(id -u)}" -ne 0 ]] || { echo "Run as jenna, without sudo."; exit 2; }

HERE="$(cd "$(dirname "$0")" && pwd)"
DASH="$HOME/.local/share/collarpet-link/dashboard.py"
APP="$HOME/.local/bin/cp-petmind-training"
ROOT=/usr/local/lib/collarpet-training-pt35
HELP=/usr/local/sbin/cp-training-ble-send
RULE=/etc/sudoers.d/collarpet-training-ble
VENV=/opt/collarpet-training-ble
BACK="$HOME/.local/share/collarpet-training-backups"
mkdir -p "$BACK" "$HOME/.local/bin"

if [[ "${2:-}" == "--rollback" ]]; then
  B=$(ls -1t "$BACK"/dashboard.py.*.bak 2>/dev/null | head -1 || true)
  [[ -n "$B" ]] || { echo "No dashboard backup."; exit 1; }
  cp "$B" "$DASH"
  echo "Dashboard rolled back. BLE helper/UI left installed."
  exit 0
fi

for f in pt35_ble_marker.py pt35_training_gui.py; do [[ -f "$HERE/$f" ]] || { echo "Missing $HERE/$f"; exit 1; }; done
[[ -f "$DASH" ]] || { echo "Missing $DASH"; exit 1; }

STAMP=$(date +%Y%m%d-%H%M%S)
cp "$DASH" "$BACK/dashboard.py.$STAMP.bak"

echo "[1/4] Preparing isolated BLE helper..."
if ! sudo test -x "$VENV/bin/python"; then sudo python3 -m venv "$VENV"; fi
if ! sudo "$VENV/bin/python" -c 'import dbus_fast' >/dev/null 2>&1; then
  echo "Installing dbus-fast (internet required once during setup)..."
  sudo "$VENV/bin/pip" install dbus-fast
fi

echo "[2/4] Installing BLE marker sender..."
sudo install -d -o root -g root -m 0755 "$ROOT"
sudo install -o root -g root -m 0755 "$HERE/pt35_ble_marker.py" "$ROOT/pt35_ble_marker.py"
TMP=$(mktemp)
cat > "$TMP" <<EOF
#!/bin/sh
exec "$VENV/bin/python" "$ROOT/pt35_ble_marker.py" "\$@"
EOF
sudo install -o root -g root -m 0755 "$TMP" "$HELP"
rm -f "$TMP"
printf 'jenna ALL=(root) NOPASSWD: %s *\n' "$HELP" | sudo tee "$RULE" >/dev/null
sudo chmod 0440 "$RULE"
sudo visudo -cf "$RULE"

echo "[3/4] Installing training GUI..."
install -m 0755 "$HERE/pt35_training_gui.py" "$APP"

echo "[4/4] Adding TRAIN button to dashboard..."
python3 - "$DASH" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text();mark="# PT35_PETMIND_TRAIN_BUTTON_V1"
if mark in s:
    print("TRAIN button already present.")
    raise SystemExit(0)
anchor="menu_button=button('MENU',open_menu)\n"
if s.count(anchor)!=1:raise SystemExit("Could not find unique MENU button anchor")
s=s.replace(anchor,anchor+mark+"\nbutton('TRAIN',lambda:subprocess.Popen([str(HOME/'.local/bin/cp-petmind-training')]))\n",1)
compile(s,str(p),"exec");p.write_text(s)
PY

python3 -m py_compile "$DASH" "$APP"

echo
if [[ -x "$HOME/.local/bin/cp-rescue" ]]; then
  echo "Recovery AP helper: FOUND"
  "$HOME/.local/bin/cp-rescue" status || true
else
  echo "WARNING: ~/.local/bin/cp-rescue is missing."
  echo "Install the manual rescue-AP helper before field use."
fi

echo "Installed. Close/reopen cp-dashboard; use TRAIN."
echo "Standalone: cp-petmind-training"
