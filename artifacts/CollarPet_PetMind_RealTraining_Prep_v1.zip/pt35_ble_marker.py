#!/usr/bin/env python3
import asyncio,os,sys
from dbus_fast import Message,Variant
from dbus_fast.aio import MessageBus
from dbus_fast.constants import BusType,MessageType,PropertyAccess
from dbus_fast.service import ServiceInterface,dbus_property,method

PATH="/com/collarpet/petmind_training_marker";MFG=0xFFFF
CONTEXT={"quiet":1,"resting":2,"speech":3,"music":4,"walking":5,"crowd":6,"machinery":7,"dark_active":8,"ef_badges":9,"fox":10,"riding":11,"outdoor":12,"other":13}
EVENT={"bang":1,"clap":2,"surprise":3,"unexpected_noise":4,"fox_appeared":5}

def make_payload(args):
    if not args:raise ValueError("missing operation")
    op=args[0].lower();seq=os.urandom(1)[0];cmd=arg=dur=0
    if op=="start":cmd=1
    elif op=="stop":cmd=2
    elif op=="clear":cmd=3
    elif op=="label":
        if len(args)<2 or args[1] not in CONTEXT:raise ValueError("unknown context label")
        cmd=4;arg=CONTEXT[args[1]];dur=max(1,min(255,int(args[2]) if len(args)>2 else 30))
    elif op=="event":
        if len(args)<2 or args[1] not in EVENT:raise ValueError("unknown event label")
        cmd=5;arg=EVENT[args[1]]
    else:raise ValueError("unknown operation")
    return b"CPTR"+bytes([1,seq,cmd,arg,dur])

class Advertisement(ServiceInterface):
    def __init__(self,data):super().__init__("org.bluez.LEAdvertisement1");self.data=data
    @dbus_property(access=PropertyAccess.READ)
    def Type(self)->'s':return "broadcast"
    @dbus_property(access=PropertyAccess.READ)
    def LocalName(self)->'s':return "CPTrain"
    @dbus_property(access=PropertyAccess.READ)
    def ManufacturerData(self)->'a{qv}':return {MFG:Variant('ay',self.data)}
    @method()
    def Release(self):pass

async def call(bus,**kw):
    r=await bus.call(Message(destination="org.bluez",**kw))
    if r.message_type==MessageType.ERROR:raise RuntimeError(r.error_name+": "+str(r.body))
    return r.body

async def main():
    data=make_payload(sys.argv[1:])
    bus=await MessageBus(bus_type=BusType.SYSTEM).connect();bus.export(PATH,Advertisement(data))
    objects=(await call(bus,path="/",interface="org.freedesktop.DBus.ObjectManager",member="GetManagedObjects"))[0]
    adapter="/org/bluez/hci0"
    if adapter not in objects:raise RuntimeError("hci0 not found")
    await call(bus,path=adapter,interface="org.bluez.LEAdvertisingManager1",member="RegisterAdvertisement",signature="oa{sv}",body=[PATH,{}])
    try:await asyncio.sleep(2.2)
    finally:
        try:await call(bus,path=adapter,interface="org.bluez.LEAdvertisingManager1",member="UnregisterAdvertisement",signature="o",body=[PATH])
        except Exception:pass
        bus.disconnect()
    print("BLE marker sent")
asyncio.run(main())
