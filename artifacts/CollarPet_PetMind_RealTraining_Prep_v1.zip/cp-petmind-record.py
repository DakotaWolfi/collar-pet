#!/usr/bin/env python3
import json,socket,sys
sock="/run/collarpet-training/control.sock"
if len(sys.argv)<2:raise SystemExit("usage: cp-petmind-record status|start|stop|clear|label NAME [SECONDS]|event NAME")
op=sys.argv[1].lower();req={"op":op}
if op=="label":
    req["label"]=sys.argv[2];req["seconds"]=int(sys.argv[3]) if len(sys.argv)>3 else 30
elif op=="event":req["label"]=sys.argv[2]
with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as s:
    s.settimeout(5);s.connect(sock);s.sendall((json.dumps(req)+"\n").encode());data=b""
    while not data.endswith(b"\n"):data+=s.recv(4096)
obj=json.loads(data);print(json.dumps(obj,indent=2));raise SystemExit(0 if obj.get("ok") else 1)
